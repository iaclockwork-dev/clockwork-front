module.exports = [
"[project]/.next-internal/server/app/entregables/nuevo/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_entregables_nuevo_page_actions_1a690677.js.map