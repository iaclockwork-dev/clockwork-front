module.exports = [
"[project]/.next-internal/server/app/entregables/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_entregables_page_actions_c0d25c23.js.map