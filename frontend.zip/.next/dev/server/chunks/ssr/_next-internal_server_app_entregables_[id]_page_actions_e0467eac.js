module.exports = [
"[project]/.next-internal/server/app/entregables/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_entregables_%5Bid%5D_page_actions_e0467eac.js.map