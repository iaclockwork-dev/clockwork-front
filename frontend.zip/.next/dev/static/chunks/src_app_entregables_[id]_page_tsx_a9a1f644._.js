(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_24499538._.js",
  "static/chunks/node_modules_f355b71e._.js"
],
    source: "dynamic"
});
