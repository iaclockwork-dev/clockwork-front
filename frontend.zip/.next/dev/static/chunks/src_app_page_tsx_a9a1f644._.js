(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_42ee6029._.js",
  "static/chunks/src_f1c38fa2._.js"
],
    source: "dynamic"
});
