module.exports=[65838,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entregables_%5Bid%5D_page_actions_e0467eac.js.map