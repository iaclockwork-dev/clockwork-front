module.exports=[82511,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entregables_nuevo_page_actions_1a690677.js.map