module.exports=[19777,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entregables_%5Bid%5D_aprobar_page_actions_f6943ba2.js.map