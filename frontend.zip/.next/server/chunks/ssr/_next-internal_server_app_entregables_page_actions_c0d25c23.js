module.exports=[73032,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entregables_page_actions_c0d25c23.js.map